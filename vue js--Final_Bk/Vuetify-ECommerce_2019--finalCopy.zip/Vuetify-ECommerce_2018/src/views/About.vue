<template>
  <div class="about">
<PreLoginHeader></PreLoginHeader>

  
     <v-app id="inspire">
    <v-content>
      <v-container fluid  >
        <v-layout align-center justify-center>
          <v-flex xs12 sm8 md4>
            <v-card class="elevation-12">
              <v-toolbar dark color="teal lighten-3">
                <v-toolbar-title>Login form</v-toolbar-title>
                <v-spacer></v-spacer>
              </v-toolbar>
              <v-card-text>

                <v-form  ref="form">
                  <v-text-field
                     prepend-icon="person"
                     name="login"
                     label="Login" 
                      placeholder="Plese Enter ur Email"
                     type="text" 
                    
                     v-model="User.email" 
                     :rules="emailRules">                   
                   </v-text-field>
                  <v-text-field
                      prepend-icon="lock"
                      name="password"
                      label="Password"
                      placeholder="Plese Enter ur Password"
                      id="password" 
                      type="password"
                      v-model="User.password"
                     :rules="passwordrules"> 
                  </v-text-field>
                </v-form>

              </v-card-text>

             
              

<!--   <v-spacer />
        <v-alert
          v-show="status"
          type="error"
          v-text="news"
          class="text-md-center"
        >
         
        </v-alert> -->



                   <v-spacer /> 

                    <p  v-show="status" v-text="news" style="text-align: center; color: red;"></p>
                   
                  <v-card-actions>
                    <v-btn left dark color="teal lighten-3" v-on:click="registation">Register</v-btn>
                    <v-spacer />
                    <v-btn v-on:click="fetchArticles" right dark color="teal lighten-3" :loading="loader">Login</v-btn>
                  </v-card-actions>

                  <v-card-actions>
                     <v-spacer />
                     <a href=""  @click="forgetPassword" >Forget Password</a>
                  </v-card-actions>
            </v-card>
          </v-flex>
        </v-layout>




       <!--   <v-progress-circular :value="90"> </v-progress-circular>   intesrtin aspect -->

       <!--  <v-layout align-center justify-center style="margin-top: 50px;">


             <v-flex xs12 sm8 md4>
             
                    <v-btn @click="auth('google')" depressed  large color="#ff9193" style="width: 100%;">Google</v-btn>
                    <v-btn @click="auth('facebook')"depressed  large color="#3B5998" style="width: 100%; color:white;">faceBook</v-btn>
                      <v-btn @click="google_login" depressed  large color="error" style="width: 100%;">Google</v-btn> 
            </v-flex>
         </v-layout>-->
         



      </v-container>
      


        

    </v-content>

  </v-app>

          
  </div>
</template>

<script>

import axios from 'axios'

 export default {


    data: () => ({

    


     
       articles: [],
       status:false,
       news:'Password or Emil does not match',
     //  validaterule: false,
       User:{
        email:'',
        password:'',
       
       },

        passwordrules: [
          (v) => !!v || 'Password is required',
          (v) => v && v.length >= 5 || 'Password must be more than 5 characters'
        ],

       emailRules: [
          (v) => !!v || 'E-mail is required',
          (v) => /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v) || 'E-mail must be valid',
         
        ],

        loader:false       
      
    }),


    methods: {
        fetchArticles: function () {
       

        this.$refs.form.validate(); // this line validate the filds are filled up correctly

       // console.log( this.$refs.form.validate());


        console.log(this.User.email,this.User.password);
        
        this.loader=true;

        axios.post('http://demosida.net/laravlFinal_extentin/public/api/auth/login',{

        email:this.User.email,
        password:this.User.password

        }).then((response) => {
       //  console.log(response.data.access_token);
        //  this.success_response(response)
         // this.$swal('login successfull');
          this.alartWithSuccess(response);
             
        }, (error) => {

        if(this.$refs.form.validate()){
          console.log(error);
          
          this.$swal.fire({
          type: 'error',
          title: 'Oops...',
          text: 'Something went wrong!',
          showConfirmButton: false,
          timer: 2000,
          footer: 'Email and password does not match'
          })

          this.catch_error();
          this.loader=false;

        }

        //  alert("Password and email does NOt Match");
        })
      },
      
      alartWithSuccess(response){

           this.loader=false;
           console.log(response.data);
           if(response.data=="Your Account has been Blocked Please contact with authority"){

                       this.$swal.fire({
                        type: 'error',
                        title: 'Attention!',
                        text: response.data,
                        showConfirmButton: true,
                       
                        
                        })

           }     

           else{

                          this.$swal({
                          position: 'bottom-middle',
                          type: 'success',
                          title: 'successfully Logged in ',
                          showConfirmButton: false,
                          timer: 2000
                          }).then(() =>{
                             this.success_response(response);
                         })

               }      



      },
      success_response(response){
       

        // this.articles = response.data;

         let token = response.data.access_token;
         localStorage.setItem("VueToken", token);

        console.log( response.data.access_token);
 
         this.$router.push('/admin');
      },

      catch_error(){

          
          this.status=true;
          //resetting field Values
/*          this.User.email='';
          this.User.password='';*/

      },

      google_login(){

        console.log('button Pressed');
        axios.get('http://demosida.net/laravlFinal_extentin/public/api/products').then((response) => {

          console.log(response);


        }, (error) => {




        })

      },
    auth(network) {
      const hello = this.hello;
      hello(network).login().then(() => {
        const authRes = hello(network).getAuthResponse();
        console.log(authRes);
        /*
          performs operations using the token from authRes
        */
        hello(network).api('me').then(function (json) {
          const profile = json;
          console.log(profile)
          /*
            performs operations using the user info from profile
          */

        });
        this.alartWithSuccess();
      })
    },
      registation(){


           this.$router.push('/registation');

      },

      forgetPassword(){

          this.$router.push('/PasswordReset');

      }




    },
       mounted(){


   
        
        console.log("i am called");

 

   }

}


</script>
