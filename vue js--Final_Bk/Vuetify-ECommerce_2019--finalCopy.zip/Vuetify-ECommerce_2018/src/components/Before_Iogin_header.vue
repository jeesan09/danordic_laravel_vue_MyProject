<template>

 




    <v-toolbar
      relative
      color="teal lighten-3"
      dark
      id="header_blogin"
      
    >
      

      <v-toolbar-title>Digital Agency Nordic</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn icon>
        <v-icon>search</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>favorite</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>more_vert</v-icon>
      </v-btn>
    </v-toolbar>







</template>
<style>
#header_blogin{
  
 
}
</style>



