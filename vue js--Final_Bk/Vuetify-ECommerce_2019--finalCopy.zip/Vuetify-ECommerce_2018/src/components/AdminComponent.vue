<template>
  
<div>


<div class="dashboard">
     <admin-header :admin="admin" :superAdmin="superAdmin" :user="user" :all="getUsers"></admin-header>
  <!--  <h1 class="pa-4 subheading grey--text">User Info</h1> -->

    <v-container class="my-5">

      <v-layout  row class="mb-3 " >
        <v-flex xs6 sm6 md3>
          <v-text-field
            v-model="search"
            placeholder="Scarch by email"
            clear-icon="mdi-close-circle"
          >
            
          </v-text-field>


        </v-flex>
        <v-flex xs4 sm6 md4>

                  <v-btn icon style="margin-top:15px;">

                     <v-icon>search</v-icon>
                  </v-btn>

        </v-flex>

     </v-layout>

      <v-layout justify-end row class="mb-3 " >



                 <v-flex  xs4 md2  sm64 lg1 style="margin-right: 20px;">
                      <v-tooltip top>
                        <div slot="activator">
                           <user-add  :parentFunctioncall="getUsers"></user-add>
                       
                        </div>
                           <span>Add new usrs </span>
                      </v-tooltip>
                 </v-flex>

       
      </v-layout>






      
      <v-card flat v-for="userdata in filteredBlogs" :key="userdata.email">
        <v-layout row wrap :class="`pa-3 project ${userdata.status   ? 'active' : 'inactive'}`">
          <v-flex xs12 sm12 md3>
            <div class="caption grey--text">Email</div>
            <div class="mb-5">{{ userdata.email }}</div>
          </v-flex>
          <v-flex xs4 sm4 md1>
            <div class="caption grey--text">Type</div>
            <div class="mb-5 mr-1">{{ userdata.type }}</div>
          </v-flex>
          <v-flex xs4 sm4 md1>
            <div class="caption grey--text"> IP</div>
            <div class="mb-5">{{ userdata.ip_address }}</div>
          </v-flex>


          <v-spacer></v-spacer>
          <v-flex xs3 sm3 md2>
            <div class="caption grey--text"> Country</div>
            <div class="mb-5">{{ userdata.country }}</div>
          </v-flex>


          <v-flex xs3 sm3 md1>
            <div class="caption grey--text">City</div>
            <div class="mb-5">{{ userdata.city }}</div>

          </v-flex>
          <v-flex xs6 sm6 md2 class="mt-2" >

          
            <v-flex xs3 sm3 md1  style="float:left; margin-right:35px; " >
             <v-tooltip bottom>
              <div slot="activator">
                <user-edit  v-bind:user_id="userdata.id"  :cll_parent="getUsers"> </user-edit>
              </div>
              <span>Assaign Role</span>
             </v-tooltip>
            </v-flex>


            <v-flex xs3 sm3 md1  style="float:left">
                <v-tooltip bottom>
                   <v-btn flat slot="activator"  @click="deleteUser(userdata.id)">
              
                  <v-icon >delete</v-icon>
                  
                  </v-btn>
                  <span>Delete This User</span>
               </v-tooltip>
            </v-flex>            
 
            
          </v-flex>
          <v-flex xs2 sm12 md1  >
            <div class="caption grey--text right " ><div class="hidden-sm-and-down">Block</div>
             <v-tooltip bottom>
               <v-switch
                color=#FF775F
                slot="activator"
                :input-value="userdata.block_status"

              
                @change="toggle(userdata.block_status,userdata.id)"
              ></v-switch>
              <span>Block this user</span>
             </v-tooltip>
            </div>

          </v-flex>


        
          <v-flex xs12 sm12 md1>
          <v-tooltip bottom>            
            <div class="right mb-5" slot="activator">
              <v-chip small :class="`${userdata.status   ? 'active' : 'inactive'} white--text my-2 caption`">{{ userdata.status   ? 'active' : 'inactive' }}</v-chip>
            </div>
             <span>User status</span>
            </v-tooltip>          
          </v-flex>



        </v-layout>
        <v-divider></v-divider>
      </v-card>


    </v-container>
   
</div>




</div>


</template>

<script>


  import Admin_Header from './admin_header.vue'
  import UserAddPooup from './UserAddPooup.vue'
  import UserEdit from './UserEdit.vue'
  import axios from 'axios'



  export default {

    components: {
     
      'admin-header' :Admin_Header,
      'user-add' :UserAddPooup,
      'user-edit':UserEdit
    },


    data() {
        return {

      userdatas:[],

      status:'',
      user_id:'',
    
      search: '',
   
       page: 1,
       length:5
       

        };
    },



    computed: {
        filteredBlogs: function(){
            return this.userdatas.filter((userdatas) => {
                return userdatas.email.match(this.search);
            });
        },

 

       }, 

    mounted() {
        
       
        this.getUsers();

         var x= '';
         x = localStorage.getItem("VueToken");
 
        console.log("token value : "+x)

        axios.get(`http://demosida.net/laravlFinal_extentin/public/api/user/type?token=${x}`,{



        }).then((response) => {

        //  console.log(response.data);

         if (response.data == 'admin') {
             

                

        
              }

         else if(response.data == 'superAdmin')  {
         



         }   

          else{
                
                this.$router.push('/');

          }

                       
         }, (error) => {
             
               this.$router.push('/');

         })


         if(x==''){


            this.$router.push('/');

         }






                 
     
     
     

               
     },

   methods: {

   getStatus(blkstatus){

    console.log("thisis "+blkstatus);
   },

   toggle(status,user_id){


     console.log("intoggle");
     console.log(status);

     var status_info;

     if(status == null){

           status = true;
           console.log('this is block status'+ status );
           console.log(user_id);
           status_info="Successfully Blocked this User";


     }

     else if(status == true){

          status = null;
          console.log('this is block status'+ status );
          status_info="Successfully Unblocked this User";
     }

      
        var xa= '';
        xa = localStorage.getItem("VueToken");
        console.log(xa);

const axiosParams = {
  headers: {
    'Content-Type': 'application/json',
    'Authorization':"Bearer "+xa,
  }
};



         axios.put(`http://demosida.net/laravlFinal_extentin/public/api/user/block/${user_id}`,{

          block_status:status
      



          },axiosParams).then((response) => {

           // console.log(response.data.email);
              
              console.log(response.data);

              if(response.data=='not Super Admin'){


                this.$swal.fire({
                type: 'error',
                title: 'Only Super Admin can Block User',
                confirmButtonColor: '#80CBC4',
               

                footer: 'Unauthorized'
                }).then(()=>{

                     this.$router.go(0);

                }

                        




                )

      
        
              }

              else{


                this.$swal({
                  position: 'bottom-middle',
                  type: 'success',
                  
           
                        
                  title: status_info,
                    
        

                  showConfirmButton: false,
                  timer: 2000
                  }).then(() =>{
                     this.afterSuccessBolck();
                 })
            
          //  this.afterRegistation();
           }

          }, (error) => {
               
                this.$swal.fire({
                type: 'error',
                title: 'Oops...',
                text: error,

                footer: error
                })

           })

   },
   
   


   getUsers(){

     console.log('Getusers called');

         var xu= '';
         xu = localStorage.getItem("VueToken");


        axios.get(`http://demosida.net/laravlFinal_extentin/public/api/allUsers?token=${xu}`,{



        }).then((response) => {

          console.log(response.data);

           this.userdatas=response.data;
           console.log("user------------------");
           console.log(this.userdatas);

         if (response.data == 'admin') {

                

        
              }

          else{
                
               

          }

                       
         }, (error) => {
             
              

         })




   }, 

 afterSuccessBolck(){
  
   this.getUsers();
 },

   deleteUser(id){


this.$swal({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#80CBC4',
  cancelButtonColor: '#FF6347',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {


  if (result.value) {


         console.log(id);
         var x= '';
         x = localStorage.getItem("VueToken");

       axios.delete(`http://demosida.net/laravlFinal_extentin/public/api/user/delete/${id}?token=${x}`,{



        }).then((response) => {



              if(response.data=='not Super Admin'){


                this.$swal.fire({
                type: 'error',
                title: 'Only Super Admin can Delete User',
               

                footer: 'Unauthorized'
                })

              


        
              }

              else{



              this.$swal({
                position: 'bottom-middle',
                type: 'success',
                title: 'Account was deleted successfully',
                showConfirmButton: false,
                timer: 2000
                }).then(() =>{
                   

                  this.getUsers();
                  

               })

             }          
         }, (error) => {

             
               

         })



  }
})



   },


    admin(){

/*       //this.getUsers();

        for(var i=0; i<this.userdatas.length; i++){

            
        //    console.log(this.userdatas[i].type);
            if(this.userdatas[i].type !== "admin"){

                
                this.userdatas.splice(i,1);


                this.admin();

            }

               
                
        }
               console.log(this.userdatas);
              
               return this.userdatas;

*/




         var xu= '';
         xu = localStorage.getItem("VueToken");


        axios.get(`http://demosida.net/laravlFinal_extentin/public/api/allAdmins/admin?token=${xu}`,{



        }).then((response) => {

          console.log(response.data);

           this.userdatas=response.data;

           console.log(this.userdatas);

         if (response.data == 'admin') {

                

        
              }

          else{
                
               

          }

                       
         }, (error) => {
             
              

         })



    },

  
    superAdmin(){


         var xu= '';
         xu = localStorage.getItem("VueToken");


        axios.get(`http://demosida.net/laravlFinal_extentin/public/api/allAdmins/superAdmin?token=${xu}`,{



        }).then((response) => {

          console.log(response.data);

           this.userdatas=response.data;

           console.log(this.userdatas);

         if (response.data == 'admin') {

                

        
              }

          else{
                
               

          }

                       
         }, (error) => {
             
              

         })
    },


    user(){


         var xu= '';
         xu = localStorage.getItem("VueToken");


        axios.get(`http://demosida.net/laravlFinal_extentin/public/api/allAdmins/user?token=${xu}`,{



        }).then((response) => {

          console.log(response.data);

           this.userdatas=response.data;

           console.log(this.userdatas);

         if (response.data == 'admin') {

                

        
              }

          else{
                
               

          }

                       
         }, (error) => {
             
              

         })
    }

   }

  }


</script>
<style>

.project.active{
  border-left: 4px solid #3CD1C2;
}
.project.inactive{
  border-left: 4px solid tomato;
}


.caption grey--text{
  margin-bottom:10px;
}


.v-chip.active{
  background: #3cd1c2;
}
.v-chip.inactive{
  background:   tomato;
}

</style>