<?php $__env->startComponent('mail::message'); ?>
# Introduction

Plese Reset Ur password by Clicking the link below <br>Token : <?php echo e($token); ?>


<?php $__env->startComponent('mail::button',['url' => 'http://localhost:8080/ComfirmPassword'] ); ?>
Rest Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<!-- ['url' => 'http://localhost:8000/api/auth/RememberPasswordViewPage'.$token] -->